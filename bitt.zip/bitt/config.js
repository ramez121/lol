module.exports = {
  secret: "uBAnoAkBCW9CCIR9uD2qhVM8v2FWf36v",
  //mongoUri: "mongodb+srv://deadpoolmde:kosomramez123123@cluster0.ws0nbsv.mongodb.net/yy62",
  mongoUri: "mongodb+srv://bavmoza47:bavmoza47@cluster0.f6mbypg.mongodb.net/bavmoza474",
  redirect_url: "https://bavvv--outlawfundes.repl.co/login",
  token: "MTEwNzI3MDAwMzQ3ODI1MzU3OA.GzKLQQ.DbNBWz4n2OSMXub7Ys99oZhqTSrp7sLivH59yM",
  prefix: "$",
  type: "online",
  owners: ["932241277850886196", "330027176642478080", "552931609842548736", "1005078120082194452", "1005082684940353536"]
}




// https://discord.com/api/oauth2/authorize?client_id=1098410555498311732&permissions=0&scope=bot

// https://discord.com/api/oauth2/authorize?client_id=1098410555498311732&redirect_uri=https%3A%2F%2Fbavvv.thebestonnnne.repl.co%2Flogin&response_type=code&scope=identify%20guilds.join