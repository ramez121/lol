module.exports = {
    name: "leave",
    run: async (client,message, args) => {
    if (!message.guild) return;
    if (!client.owners.includes(message.author.id)) return;
    let guildId = args[0]
    let guild = client.guilds.cache.get(guildId)
    if (!guildId || !guild) return message.reply({content: `I'm not in this guild .`})
    guild.leave()
    message.reply({content: `Successfully left **${guild.name}**`})
    },
};