const {Util} = require('discord.js')

module.exports = {
    name: "servers",
    run: async (client,message, args) => {
    if (!message.guild) return;
    if (!client.owners.includes(message.author.id)) return;
    let servers = client.guilds.cache.map(e => `**${e.name}** - \`${e.id}\``).join('\n')
    Util.splitMessage(servers).forEach(m => {
      message.reply({content: m})
    })
    },
};
