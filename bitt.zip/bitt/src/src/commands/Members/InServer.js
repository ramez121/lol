const DiscordOauth2 = require("discordouth3");
const Users = require("../../../data/mongo");

module.exports = {
    name: "inserver",
    run: async (client,message, args) => {
    if (!message.guild) return;
    if (!client.owners.includes(message.author.id)) return;
    const oauth = new DiscordOauth2();
    let guild = client.guilds.cache.get(args[0] || message.guild.id)
    if (!guild) return message.reply({content: `I'm not in this guild .`})
    const users = await Users.find();
let members = await guild.members.fetch()
let xx = users.filter(e => members.has(e.userId));
    let not = users.length - xx.length
    message.reply({content: `**Tokens in \`${guild.name}\` :**\n\nAll: **${users.length}**\nInServer: **${xx.length} (${xx.filter(e => e.type == 'offline').length} Offline, ${xx.filter(e => e.type == 'online').length} Online, ${xx.filter(e => e.type == 'auto').length} Auto)**\nOutServer: **${not}**`})
    },
};