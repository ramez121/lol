const DiscordOauth2 = require("discordouth3");
const Users = require("../../../data/mongo");

module.exports = {
    name: "stock",
    run: async (client,message, args) => {
    if (!message.guild) return;
    if (!client.owners.includes(message.author.id)) return;
    const oauth = new DiscordOauth2();
    const users = await Users.find();
    message.reply({content: `All Tokens in bot: **${users.length} (${users.filter(e => e.type == 'offline').length} Offline, ${users.filter(e => e.type == 'online').length} Online, ${users.filter(e => e.type == 'auto').length} Auto)**`})
    },
};