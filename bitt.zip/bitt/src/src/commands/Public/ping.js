module.exports = {
    name: "ping",
    run: async (client,message, args) => {
      message.reply({content: `Ping **${client.ws.ping}ms**!`})
    },
};